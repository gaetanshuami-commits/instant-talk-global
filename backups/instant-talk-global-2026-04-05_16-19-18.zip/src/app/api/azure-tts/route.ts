﻿import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";

function escapeXml(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function inferLocaleFromVoice(voiceName?: string) {
  if (!voiceName) return "en-US";
  const match = voiceName.match(/^([a-z]{2,3}-[A-Z]{2})-/);
  return match?.[1] ?? "en-US";
}

const DEFAULT_VOICE_BY_LANG: Record<string, string> = {
  FR: "fr-FR-DeniseNeural",
  EN: "en-US-JennyNeural",
  ES: "es-ES-ElviraNeural",
  DE: "de-DE-KatjaNeural",
  ZH: "zh-CN-XiaoxiaoNeural",
  AR: "ar-SA-ZariyahNeural",
  HI: "hi-IN-SwaraNeural",
  PT: "pt-BR-FranciscaNeural",
  RU: "ru-RU-SvetlanaNeural",
  JA: "ja-JP-NanamiNeural",
  IT: "it-IT-ElsaNeural",
  NL: "nl-NL-ColetteNeural",
  EL: "el-GR-AthinaNeural",
  SV: "sv-SE-SofieNeural",
  NO: "nb-NO-PernilleNeural",
  DA: "da-DK-ChristelNeural",
  FI: "fi-FI-NooraNeural",
  PL: "pl-PL-ZofiaNeural",
  UK: "uk-UA-PolinaNeural",
  CS: "cs-CZ-VlastaNeural",
  SK: "sk-SK-ViktoriaNeural",
  HU: "hu-HU-NoemiNeural",
  RO: "ro-RO-AlinaNeural",
  BG: "bg-BG-KalinaNeural",
  KO: "ko-KR-SunHiNeural",
  TR: "tr-TR-EmelNeural",
  HE: "he-IL-HilaNeural",
  SW: "sw-KE-ZuriNeural"
};

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const text = String(body?.text ?? "").trim();
    const lang = String(body?.lang ?? "EN").toUpperCase();
    const voiceName =
      String(body?.voiceName ?? "").trim() ||
      DEFAULT_VOICE_BY_LANG[lang] ||
      "en-US-JennyNeural";

    if (!text) {
      return NextResponse.json(
        { error: "Text content required" },
        { status: 400 }
      );
    }

    const key = process.env.AZURE_SPEECH_KEY;
    const region = process.env.AZURE_SPEECH_REGION || process.env.AZURE_REGION;

    if (!key || !region) {
      return NextResponse.json(
        {
          error: "Azure credentials not configured",
          hasKey: Boolean(key),
          hasRegion: Boolean(region),
        },
        { status: 500 }
      );
    }

    const locale = inferLocaleFromVoice(voiceName);

    const ssml = `
<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="${locale}">
  <voice name="${voiceName}">
    ${escapeXml(text)}
  </voice>
</speak>`.trim();

    const response = await fetch(
      `https://${region}.tts.speech.microsoft.com/cognitiveservices/v1`,
      {
        method: "POST",
        headers: {
          "Ocp-Apim-Subscription-Key": key,
          "Content-Type": "application/ssml+xml",
          "X-Microsoft-OutputFormat": "riff-24khz-16bit-mono-pcm",
          "User-Agent": "instant-talk-global",
        },
        body: ssml,
        cache: "no-store",
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error("[Azure TTS] Error:", {
        status: response.status,
        statusText: response.statusText,
        voiceName,
        locale,
        region,
        errorText,
      });

      return NextResponse.json(
        { error: "TTS synthesis failed", details: errorText },
        { status: response.status }
      );
    }

    const audioBuffer = await response.arrayBuffer();

    return new NextResponse(audioBuffer, {
      headers: {
        "Content-Type": "audio/wav",
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    console.error("[Azure TTS Route] Error:", error);
    return NextResponse.json(
      {
        error: "Internal server error",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 }
    );
  }
}


